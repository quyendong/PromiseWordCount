/*
Quyen Dong
W899090
HW3
CSC440
Assignment:
The input file for this HW is called input.txt.
Readline uses the traditional callback syntax.

For this homework write a Promise based function that
    reads the contents of the file that resolves to a
    Javascript object whose keys are the distinct words
    in the file and whose values are the word counts.
In otherwords, this JavaScript object a histogram.
You will chain this promise with a then that uses
    readline to ask for a word from the user and
    once given it outputs the word count.
*/
//fs.readfile(path, {encoding, flag}, callback) -async
//fs.readfileSync(path, {encoding, flag}) -sync

//promise takes 2 arguments
//resolve --> successful, you finished what you had to do
//reject --> failure, promise is not fulfilled, rejected
console.log("Through a promise, this program reads in a file, prompts user for input, and performs a word count.")
let promise = new Promise(function(resolve, reject){
    console.log('Attempting to read input.txt..');
    const fs = require('fs');
    const inputfile = "input.txt";
    let data = {}
    fs.readFile(inputfile, (err, data)=> {
        if (err)
        {
            //console.log(err.message);
            reject(false);
        }
        else
        {   
            console.log('File was read.');
            let stringdata = data.toString();
            stringdata = stringdata.replace(/(\r\n|\n|\r)/gm," ");
            stringdata = stringdata.replace(",", " ");
            stringdata = stringdata.replace("/", " ");
            stringdata = stringdata.replace(".", " ");
            stringdata = stringdata.replace("  ", " ");
            words = stringdata.split(" ");    //split document into array of words 
            key = Object.keys(words); 
            //makes key the index numbers for the array words which contains 
            //all the words in input txt
            for (key in words) 
            {
               words[key] = words[key].replace(",", "");
               words[key] = words[key].replace("(", "");
               words[key] = words[key].replace(")", "");
               words[key] = words[key].replace(".", "");
               words[key] = words[key].replace(".", "");
               if (words[key] == '')
                {
                    words.splice(key, 1); //remove one element starting @ position key
                }
            } 
            //console.log(key); //displays how many keys
            //console.log(words); //displays array of words
            resolve(true);
        } 
    })
}).then(function(value){
    let flag = value;
    if  (flag == false)
    {
        console.log("There is an error in your then function.")
    }
    else 
    {
        const readline = require('readline');
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        })
        rl.question('Please enter a word you\'d like to search for. \n', (answer) => {
            console.log(`You answered: ${answer}`);
        //console.log(words); //troubleshooting
        //console.log(key); //troubleshooting
        let ans = answer;
        let wordCount = 0;
        for (key in words)
        {
            if (ans == words[key])
            {
                wordCount = wordCount + 1;
            }
        }
        console.log("Key: ", ans);
        console.log("Count: ", wordCount);
        console.log('Program exiting ... Goodbye!');
        rl.close();
        });
    }
});


